import streamlit as st
import pandas as pd
import sqlite3
import os

st.set_page_config(page_title="자동차 리콜·결함 안전등급 대시보드", layout="wide")

DB_PATH = os.path.join("db", "recall.db")


# ---------------------------
# DB 연결 & 조회 함수
# ---------------------------
@st.cache_resource
def get_connection():
    return sqlite3.connect(DB_PATH, check_same_thread=False)


@st.cache_data(ttl=600)
def get_filter_options():
    conn = get_connection()
    models = pd.read_sql("SELECT DISTINCT car_model FROM recalls ORDER BY car_model", conn)["car_model"].tolist()
    makers = pd.read_sql("SELECT DISTINCT manufacturer FROM recalls ORDER BY manufacturer", conn)["manufacturer"].tolist()
    grades = pd.read_sql("SELECT DISTINCT safety_grade FROM recalls ORDER BY safety_grade", conn)["safety_grade"].tolist()
    return models, makers, grades


@st.cache_data(ttl=600)
def search_recalls(car_model, manufacturer, grade):
    conn = get_connection()
    query = "SELECT * FROM recalls WHERE 1=1"
    params = []

    if car_model != "전체":
        query += " AND car_model = ?"
        params.append(car_model)
    if manufacturer != "전체":
        query += " AND manufacturer = ?"
        params.append(manufacturer)
    if grade != "전체":
        query += " AND safety_grade = ?"
        params.append(grade)

    query += " ORDER BY recall_date DESC"
    return pd.read_sql(query, conn, params=params)


# ---------------------------
# DB 파일 존재 확인
# ---------------------------
if not os.path.exists(DB_PATH):
    st.error("DB 파일이 없습니다. 먼저 터미널에서 `python load_data.py`를 실행해주세요.")
    st.stop()

model_options, maker_options, grade_options = get_filter_options()

# ---------------------------
# 화면 구성
# ---------------------------
st.title("🚗 자동차 리콜·결함 안전등급 대시보드")
st.caption("차종 · 기업 · 결함 안전등급을 검색해보세요")

st.divider()

col1, col2, col3 = st.columns([2, 2, 1])
with col1:
    car_model_input = st.selectbox("차종", ["전체"] + model_options)
with col2:
    manufacturer_input = st.selectbox("기업(제작사)", ["전체"] + maker_options)
with col3:
    grade_input = st.selectbox("안전등급", ["전체"] + grade_options)

search_btn = st.button("🔍 검색", use_container_width=True)

st.divider()

# ---------------------------
# 검색 실행 (버튼을 누르지 않아도 처음엔 전체 표시)
# ---------------------------
if search_btn or "df_result" not in st.session_state:
    st.session_state.df_result = search_recalls(car_model_input, manufacturer_input, grade_input)

df_result = st.session_state.df_result

st.subheader(f"검색 결과 ({len(df_result)}건)")

if df_result.empty:
    st.warning("검색 결과가 없습니다. 조건을 다시 확인해주세요.")
else:
    display_df = df_result[
        ["manufacturer", "car_model", "recall_date", "defect_category", "safety_grade", "affected_count", "status"]
    ].rename(columns={
        "manufacturer": "제작사",
        "car_model": "차종",
        "recall_date": "리콜일자",
        "defect_category": "결함부위",
        "safety_grade": "안전등급",
        "affected_count": "대상대수",
        "status": "진행상태",
    })
    st.dataframe(display_df, use_container_width=True, hide_index=True)

    # ---------------------------
    # 상세 조회
    # ---------------------------
    st.subheader("📋 상세 조회")
    selected_model = st.selectbox(
        "상세히 볼 차종 선택",
        df_result["car_model"].unique(),
        key="detail_select",
    )
    detail = df_result[df_result["car_model"] == selected_model].iloc[0]

    c1, c2 = st.columns(2)
    with c1:
        st.metric("제작사", detail["manufacturer"])
        st.metric("안전등급", detail["safety_grade"])
        st.metric("진행상태", detail["status"])
    with c2:
        st.metric("리콜 대상 대수", f"{detail['affected_count']:,}대")
        st.metric("리콜일자", detail["recall_date"])
        st.metric("결함부위", detail["defect_category"])

    st.write("**결함 상세 내용**")
    st.info(detail["defect_detail"])
