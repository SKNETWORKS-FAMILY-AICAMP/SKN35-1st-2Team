"""
recall_data.csv -> db/recall.db (SQLite) 적재 스크립트
실행: python load_data.py
"""

import pandas as pd
import sqlite3
import os

CSV_PATH = os.path.join("data", "recall_data.csv")
DB_PATH = os.path.join("db", "recall.db")


def load_csv_to_db(csv_path=CSV_PATH, db_path=DB_PATH):
    # 1. CSV 읽기
    df = pd.read_csv(csv_path, encoding="utf-8-sig")

    # 2. 간단한 전처리 (공백 제거, 결측치 처리)
    text_cols = ["manufacturer", "car_model", "defect_category", "defect_detail", "status"]
    for col in text_cols:
        df[col] = df[col].astype(str).str.strip()

    df["affected_count"] = df["affected_count"].fillna(0).astype(int)

    # 3. DB 폴더 없으면 생성
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    # 4. SQLite에 저장
    conn = sqlite3.connect(db_path)
    df.to_sql("recalls", conn, if_exists="replace", index=False)

    # 5. 검색 성능을 위한 인덱스 생성
    cur = conn.cursor()
    cur.execute("CREATE INDEX IF NOT EXISTS idx_manufacturer ON recalls(manufacturer)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_car_model ON recalls(car_model)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_safety_grade ON recalls(safety_grade)")
    conn.commit()
    conn.close()

    print(f"[완료] {len(df)}건 적재 -> {db_path}")


if __name__ == "__main__":
    load_csv_to_db()
